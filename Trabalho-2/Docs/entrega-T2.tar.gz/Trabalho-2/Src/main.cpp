#include "simulator.h"

using namespace std;

int main() {
    Simulator sm = Simulator();
    sm.run();
}

