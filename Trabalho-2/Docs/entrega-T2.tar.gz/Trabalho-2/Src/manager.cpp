#include "manager.h"

Manager::Manager() {}

Manager::~Manager() {}
